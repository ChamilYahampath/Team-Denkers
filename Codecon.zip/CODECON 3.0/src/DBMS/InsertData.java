/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBMS;

import java.awt.Component;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Kasun Dhananjaya
 */
public class InsertData  extends DBMSconnection{
    private String Password,D1,D2;
    double FclassTicketPrice,SecondFClassTktPRice,ThirdFClassTktPRice,Amount;
    private String TktNumber;
    private String Date;
    private String cls;
    private String amt;
    private String total;
    public InsertData() {
    }
    public void InsertData(String fname, String lname, String nic,String tel,String User,String Password ) throws ClassNotFoundException, SQLException
    {
        super.databaseConnection();
        String statement= "INSERT INTO `login`(`Fname`, `Lname`, `NIC`, `Tel`, `UserName`, `Password`) VALUES (?,?,?,?,?,?);";
        PreparedStatement ps= super.getCon().prepareStatement(statement);
        ps.setString(1, fname);
        ps.setString(2, lname);
        ps.setString(3, nic);
        ps.setString(4, tel);
        ps.setString(5, User);
        ps.setString(6, Password);
        ps.executeUpdate();
        super.closeDBcon();
    }
    public void RetriewData(String Uname) throws ClassNotFoundException, SQLException
    {
        super.databaseConnection();
        Statement statement=super.getCon().createStatement();
        String stmt="SELECT Password FROM login where UserName = '"+Uname+"'";
        ResultSet rst=statement.executeQuery(stmt);
        if(rst.next()){
            Password=(rst.getString(1));
        }
        super.closeDBcon();
    }
   public String getPassword(String UN) throws ClassNotFoundException, SQLException
   {
       RetriewData(UN);
       return(Password);
   }
   public void Insert1STForm(String date, String from, String to) throws ClassNotFoundException, SQLException
   {
        GennerateTID GTID= new GennerateTID();
        super.databaseConnection();
        String statement="INSERT INTO `normalticket` (`TicketNumber`, `Date`, `From`, `To`) VALUES (?, ?, ?, ?);" ;
        PreparedStatement ps=super.getCon().prepareStatement(statement);
        ps.setString(1, GTID.GenerateTID());
        ps.setString(2, date);
        ps.setString(3, from);
        ps.setString(4, to);
        ps.executeUpdate();
        super.closeDBcon();
   }
    
   public void Insert2ndFrom(String adult, String Child, String Cls, String Jurny) throws ClassNotFoundException, SQLException
   {
       super.databaseConnection();
        String statement= "UPDATE `normalticket` SET `Adult`=?,`Child`=?,`Class`=?,`JureyType`=? WHERE TicketNumber = (SELECT max(TicketNumber) from normalticket)";
        PreparedStatement ps=super.getCon().prepareStatement(statement);
        ps.setString(1, adult);
        ps.setString(2, Child);
        ps.setString(3, Cls);
        ps.setString(4,Jurny);
        ps.executeUpdate();
        super.closeDBcon();
   }
   public void FClassTktPRice() throws ClassNotFoundException, SQLException
   {
       super.databaseConnection();
        Statement statement=super.getCon().createStatement();
        String stmt="SELECT  `first` FROM `ticketprice` WHERE (D1='"+SelectD1()+"' and D2='"+SelectD2()+"') or (D1='"+SelectD2()+"' and D2='"+SelectD1()+"')";
        ResultSet rst=statement.executeQuery(stmt);
        if(rst.next()){
            FclassTicketPrice=(rst.getDouble(1));
        }
        super.closeDBcon();
   }
   public double getFClassTktPRice()
   {
       return (FclassTicketPrice);
   }
   
      public void SecondClassTktPRice() throws ClassNotFoundException, SQLException
   {
       super.databaseConnection();
        Statement statement=super.getCon().createStatement();
        String stmt="SELECT  `second` FROM `ticketprice` WHERE (D1='"+SelectD1()+"' and D2='"+SelectD2()+"') or (D1='"+SelectD2()+"' and D2='"+SelectD1()+"')";
        ResultSet rst=statement.executeQuery(stmt);
        if(rst.next()){
            SecondFClassTktPRice=(rst.getDouble(1));
        }
        super.closeDBcon();
   }
   public double getSecondFClassTktPRice()
   {
       return (SecondFClassTktPRice);
   }
   
    public void ThirdClassTktPRice() throws ClassNotFoundException, SQLException
   {
       super.databaseConnection();
        Statement statement=super.getCon().createStatement();
        String stmt="SELECT  `Third` FROM `ticketprice` WHERE (D1='"+SelectD1()+"' and D2='"+SelectD2()+"') or (D1='"+SelectD2()+"' and D2='"+SelectD1()+"')";
        ResultSet rst=statement.executeQuery(stmt);
        if(rst.next()){
            ThirdFClassTktPRice=(rst.getDouble(1));
        }
        super.closeDBcon();
   }
   public double getThirdFClassTktPRice()
   {
       return (ThirdFClassTktPRice);
   }
   public String SelectD1() throws ClassNotFoundException, SQLException
   {
      super.databaseConnection();
        Statement statement=super.getCon().createStatement();
        String stmt="SELECT `From` FROM `normalticket` WHERE TicketNumber = (select max(TicketNumber) from `normalticket`)";
        ResultSet rst=statement.executeQuery(stmt);
        if(rst.next()){
            D1=(rst.getString(1));
        }
        super.closeDBcon();
      return(D1);
   }
      public String SelectD2() throws ClassNotFoundException, SQLException
   {
      super.databaseConnection();
        Statement statement=super.getCon().createStatement();
        String stmt="SELECT `to` FROM `normalticket` WHERE TicketNumber = (select max(TicketNumber) from `normalticket`)";
        ResultSet rst=statement.executeQuery(stmt);
        if(rst.next()){
            D2=(rst.getString(1));
        }
        super.closeDBcon();
      return(D2);
   }
      public double Amounnt(int numberOfAcults, int NumberOfChild,String Cls) throws ClassNotFoundException, SQLException
      {
        CalculateAmount(numberOfAcults,NumberOfChild,Cls);
          return(Amount);
      }
      public void CalculateAmount(int numberOfAcults, int NumberOfChild,String Cls) throws ClassNotFoundException, SQLException
      { 
          
         if(Cls =="1")
         {
             FClassTktPRice();
             Amount= numberOfAcults*getFClassTktPRice()+(NumberOfChild*getFClassTktPRice())/2;
         } 
        else if(Cls=="2")
        {
            SecondClassTktPRice();
            Amount= numberOfAcults*getSecondFClassTktPRice()+(NumberOfChild*getSecondFClassTktPRice())/2;
        }
        else if(Cls=="3")
        {
            ThirdClassTktPRice();
            Amount= numberOfAcults*getThirdFClassTktPRice()+(NumberOfChild*getThirdFClassTktPRice())/2;
        }
          
      }
    public void InsertAmount(double amount) throws ClassNotFoundException, SQLException
    {
        super.databaseConnection();
        String statement="UPDATE `normalticket` SET `Amount`=? WHERE TicketNumber = (SELECT MAX(TicketNumber) From normalticket);" ;
        PreparedStatement ps=super.getCon().prepareStatement(statement);
        ps.setDouble(1,amount );
        ps.executeUpdate();
        super.closeDBcon();
    }
    public void RetriewFinal() throws ClassNotFoundException, SQLException
    {
        super.databaseConnection();
        Statement statement=super.getCon().createStatement();
        String stmt="SELECT `TicketNumber`, `Date`, (Child+Adult) As 'total', `Class`, `Amount` FROM `normalticket` WHERE TicketNumber=(SELECT max(TicketNumber) from `normalticket`);";
        ResultSet rst=statement.executeQuery(stmt);
        if(rst.next()){
            TktNumber=(rst.getString(1));
            Date=(rst.getString(2));
            total = rst.getString(3);
            cls=(rst.getString(4));
            amt=(rst.getString(5));
        }
        super.closeDBcon();
    }
    public String getTktNumber() throws ClassNotFoundException, SQLException
    {
        RetriewFinal();
        return(TktNumber);
    }
        public String getDate() throws ClassNotFoundException, SQLException
    {
        RetriewFinal();
        return(Date);
    }
        public String getTotal() throws ClassNotFoundException, SQLException
    {
        RetriewFinal();
        return(total);
    }
        public String getcls() throws ClassNotFoundException, SQLException
    {
        RetriewFinal();
        return(cls);
    }
    public String getamt() throws ClassNotFoundException, SQLException
    {
        RetriewFinal();
        return(amt);
    }
 
        
        
    
        
    
}
