/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBMS;

import com.google.zxing.NotFoundException;
import com.google.zxing.WriterException;
import java.io.IOException;
import java.sql.SQLException;

/**
 *
 * @author Kasun Dhananjaya
 */
public class main {
    public static void main(String[] args) throws ClassNotFoundException, SQLException, WriterException, IOException, NotFoundException
    {
        QRgen qr = new QRgen();
        qr.Generate();
    }
    
}
