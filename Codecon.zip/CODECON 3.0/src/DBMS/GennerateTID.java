/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBMS;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Kasun Dhananjaya
 */
public class GennerateTID extends DBMSconnection{
    int LDidintPart;
    String TID="0",GeneratedTID,LastRDID;
    public GennerateTID() {
    }
    
     public int getPofRecords() throws SQLException, ClassNotFoundException
    {
        seprateINT();
        
        return(LDidintPart+1);
    }
    public int CalculateLen(int n)
       {
           int count =0;
           while(n!=0)
           {
               n /= 10;
               count++;
           }
           return(count);
       }
    public String GenerateTID() throws SQLException, ClassNotFoundException{
    {
        getMaxIndex();
        seprateINT();
        for(int i=0; i<4-CalculateLen(getPofRecords());i++)
        TID=TID+"0";
    }
        GeneratedTID="NT"+TID+getPofRecords();
        return(GeneratedTID);
}
    public void getMaxIndex() throws ClassNotFoundException, SQLException
    {
        super.databaseConnection();
        Statement statement=super.getCon().createStatement();
        String stmt="SELECT max(TicketNumber) from normalticket;";
        ResultSet rst=statement.executeQuery(stmt);
        if(rst.next()){
            LastRDID=rst.getString(1);
        }
        super.closeDBcon();
 }   
    public void seprateINT() throws ClassNotFoundException, SQLException
    {
        getMaxIndex();
        
        StringBuffer num= new StringBuffer();
        for(int i=0;i<LastRDID.length();i++)
        {
            if(Character.isDigit(LastRDID.charAt(i)))
            {
                num.append(LastRDID.charAt(i));
            }
        }
            LDidintPart=Integer.parseInt(num.toString());
    }
}
